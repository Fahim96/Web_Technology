<?php
error_reporting(0);
session_start();
$cpass = $_POST['cpass'];
$npass = $_POST['npass'];
$rpass = $_POST['rpass'];
$id=$_SESSION['id'];
echo $id;



  $server="localhost";
  $username="root";
  $password="";
  $db="labfinal";
  
  $mycon = mysqli_connect($server,$username,$password,$db);
  $sql = "select * from user where id='$id'";
  
  $result=mysqli_query($mycon,$sql);
  $row=mysqli_fetch_assoc($result);
  $rown=mysqli_num_rows($result);
  
  if( $rown == 1)
  {  
	  $p = $row['password'];
	  echo $p;
		

  }
  
 

if(!empty($_POST['cpass']) && !empty($_POST['rpass']) && !empty($_POST['npass']) )
{
	if($cpass == $p) 
	{
		if($npass == $rpass )
		{
			 $sql2 = "update user set password='$npass' where id='$id'";
             if($result=mysqli_query($mycon,$sql2))
	                   echo ("password changed successfully");			 
		}
		else
			echo ("new pass and retype pass should be same");
	}
	else
		echo ("current password doesn't match");
}
else
	echo "fill up the full form";


?>