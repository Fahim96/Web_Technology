<?php
  session_start();
  $fid=$_POST['id'];
  $fpassword=$_POST['fpass'];
  
  $server="localhost";
  $username="root";
  $password="";
  $db="labfinal";
  
  $mycon = mysqli_connect($server,$username,$password,$db);
  
  if(!$mycon)
	  die("connection error");
  
  $sql = "select * from user where id='$fid' AND password='$fpassword'";
  
  if($result=mysqli_query($mycon,$sql))
	  
	  
  $row=mysqli_fetch_assoc($result);
  $rown=mysqli_num_rows($result);
  
  if( $rown == 1  && $row['usertype'] == "user")
  {  
      //SETCOOKIE ("name" , "$row['name']",time()+1000,"/");
	  //SETCOOKIE ("id" , "$row['id']",time()+1000,"/");
	  //SETCOOKIE ("type" , "$row['usertype']",time()+1000,"/");
	  $_SESSION['name'] = $row['name'];
	   $_SESSION['id'] = $row['id'];
	    $_SESSION['usertype']  = $row['usertype'];
		
		//echo   $_SESSION['name'] ;
	  
	  header("location: user_home.html");
  }
   if ( $rown == 1  && $row['usertype'] == "admin")
  {
	 $_SESSION['name'] = $row['name'];
	   $_SESSION['id'] = $row['id'];
	    $_SESSION['usertype']  = $row['usertype'];
	    $_SESSION['password']  = $row['password'];
		
		//echo   $_SESSION['name'] ;
	  
	  header("location: admin_home.html");  
  }
?>