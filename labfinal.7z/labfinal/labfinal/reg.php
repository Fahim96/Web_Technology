<?php
  
  $fid=$_POST['id'];
  $fpassword=$_POST['fpass'];
  $fname=$_POST['name'];
  $fuser=$_POST['utype'];
  
  $server="localhost";
  $username="root";
  $password="";
  $db="labfinal";
  
  $mycon = mysqli_connect($server,$username,$password,$db);
  
  if(!$mycon)
	  die("connection error");
  
  $sql = "insert into user values('$fid','$fpassword','$fname','$fuser')";
  
  if($result=mysqli_query($mycon,$sql))
  { echo ("sign up successful");
  HEADER("location : login.html");}
  else
	  echo ("check the form again");
  
  
  
  
?>