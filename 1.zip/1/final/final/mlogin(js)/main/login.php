<?php include('functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login system</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


	<div class="header">
		<h2><center>Login</center></h2>
	</div>

	<div class="imgcontainer">
    <img src="../login1.png"  class="avatar">
  </div>
	
	<form method="post" action="login.php">

		<?php echo display_error(); ?>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<br/>
		<div class="input-group">
			<button type="submit" class="btn" name="login_btn">Login</button>
			
		</div>
		<p>
			Not yet a member? <a href="register.php">Sign up</a>
		</p>

    <a href="../index.html">HOME</a>

	</form>


</body>
</html>