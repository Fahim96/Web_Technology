<?php include('functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2><center>Registration</center></h2>
	</div>
	<div class="imgcontainer">
    <img src="../reg.png"  class="avatar">
  </div>
	<form method="post" action="Register.php"  onsubmit="return validation()" >

		<?php echo display_error(); ?>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" id="user" value="<?php echo $username; ?>">
		     <span id="username" class="text-danger" ></span>
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email" id="emails" value="<?php echo $email; ?>">
		<span id="emailids" class="text-danger" ></span>
		</div>

		<div class="input-group">
			<label>User type</label>
			<select name="user_type" id="user_type" >
				<option value=""></option>
				<option value="admin">Admin</option>
				<option value="user">User</option>
			</select>
		</div>
		
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1"id="pass">
		<span id="passwords" class="text-danger" ></span>
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="password_2"id="conpass">
		<span id="confirmpass" class="text-danger" ></span>
		</div>
		
		<div class="input-group">
			<button type="submit" class="btn" name="register_btn">Register</button>
		</div>
		<p>
			Already a member? <a href="login.php">Sign in</a>
		</p>
		<a href="../index.html">HOME</a>

	</form>
	
	<script type="text/javascript">
	  
	  function validation(){
		
		var user= document.getElementById('user').value; 
		var emails= document.getElementById('emails').value; 
		 var pass= document.getElementById('pass').value;
		 var confirmpass= document.getElementById('conpass').value;
		 
		 
		  if(user==""){
			document.getElementById('username').innerHTML="** please fill the username "; 
			return false;
			  }
			  
			 if((user.length<= 2)||(user.length >20)){
				  
				 document.getElementById('username').innerHTML="** username must be between 2 to 20"; 
			return false; 
				  
			  }
			  
			  if(!isNaN(user)){
				  document.getElementById('username').innerHTML="** only charecters are allowed"; 
			return false; 
				  
			  }
			  
			  
			  
		   if(emails==""){
			document.getElementById('emailids').innerHTML="** please fill the email "; 
			return false;
			  }
			   
			  
			/*if(emails.indexOf('@')<= 0){
			document.getElementById('emailids').innerHTML="** @ invalid position,bob@gmail.com "; 
			return false;
			  } 
			 
			 if(emails charAt(emails.length-4)!='.'){
			document.getElementById('emailids').innerHTML="** . invalid position,bob@gmail.com "; 
			return false;
			  }*/
			    
			   
			if(pass==""){
			document.getElementById('passwords').innerHTML="** please fill the password "; 
			return false;}
			
			
			if(pass.length<= 5){
				  document.getElementById('passwords').innerHTML="** passwords is short,minimum 5 charecter!"; 
			return false;  
				  }
			
			if(pass!=confirmpass){
			document.getElementById('passwords').innerHTML="** password are not matching "; 
			return false;}
			
			
		   if(conpass==""){
			document.getElementById('confirmpass').innerHTML="** please fill the confirmpassword "; 
			return false;}

	  }
	
	</script>

	
</body>
</html>