<?php
	include('functions.php');
	require_once('db.php');

    if(isset($_SESSION['user'])){
        $conn = getConnection();
    	
?>
<link rel="stylesheet" href="style_a.css"/>
<?php include("header.php")?>

<?php include ("nav.php") ?><br><br>
<fieldset>
    <legend><b>PROFILE</b></legend>
	<form>
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><?=$_SESSION['user']['username']?></td>
				<td rowspan="7" align="center">
					
                    <br/>
                   
				</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><?=$_SESSION['user']['email']?></td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>			
			
		</table>	
        <hr/>
        <a href="edit_prof.php">Edit Profile</a>	
	</form>
</fieldset>
<?php include("footer.php")?>
<?php

}else{
    header("location: login.php");
}
?>