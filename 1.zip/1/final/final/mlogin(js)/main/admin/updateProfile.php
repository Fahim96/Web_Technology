<?php
    include('functions.php'); 
	require_once('db.php');
	
if(isset($_POST['update'])){

	//catch data
	$username = $_REQUEST['name'] ;
	$email = $_REQUEST['email'];

	//validate data

		if($username == "" || $email == ""){
			header("location: edit_prof.php?status=errorNull");
		}else{

			$conn = getConnection();
			$sql = "UPDATE users SET username='$username', email='$email' WHERE id='".$_SESSION['user']['id']."'";

			echo $sql;
			
			if(mysqli_query($conn, $sql)){

				header("location: edit_prof.php?status=success");
			}else{
				header("location: edit_prof.php?status=dbError");
			}

		}
}
	
?>