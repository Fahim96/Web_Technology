<div class="topnav">
	<a href="Admin_dashboard.php">Dashboard</a>
  <a href="prof.php">Profile</a>
  <a href="manage_pro.php">Manage Product</a>
  <a href="view_ven.php">UserInfo</a>
  <a href="viewproduct.php">View products</a>
  <a href="example.php">Contact</a>

 
  <a href="../login.php" style="float:right">Log Out</a>
</div>