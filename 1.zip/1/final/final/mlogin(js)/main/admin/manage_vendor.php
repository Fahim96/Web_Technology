<html>
<head>
<link rel="stylesheet" href="style_a.css"/>
</head>
<body>

<?php include("header.php")?>

<?php include ("nav.php") ?>

<h1>manage vendor </h1>



<?php include("footer.php")?>
</body>
</html>