
<?php
	 include('functions.php');
	require_once('db.php');
   
    if(isset($_SESSION['user'])){
		
			
		
?>
<link rel="stylesheet" href="style_a.css"/>
<?php include("header.php")?>
<?php include ("nav.php") ?>

<center>
	<table border="1" cellpadding="5" cellspacing="0">
		<tr><td colspan="4" align="CENTER">Users Info</td></tr>
		<tr>
			<td>NAME</td><td>EMAIL ADDRESS</td>
		</tr>
		
			<?php
			
				$conn = getConnection();
    	
		$sql = "select * from users";
		
		
		$query = mysqli_query($conn,$sql);
			
			if(mysqli_num_rows($query)>0)
			{
				
				while($row=mysqli_fetch_assoc($query))
				{
					$id1=$row['id'];
					$username=$row['username'];
					$email = $row['email'];
					
					echo "<tr>";
					
					//echo "<td>".$id1."</td>";
					echo "<td>".$username."</td>";
					echo "<td>".$email."</td>";
					
					echo "</tr><br>";
					
				}
			}
				
		
		
		
		
		
		
		
		
		
		
    
?>
		
		
		
		
	</table>
	
</center>

<?php include("footer.php")?>







<?php

}else{
    header("location: login.php");
}
?>