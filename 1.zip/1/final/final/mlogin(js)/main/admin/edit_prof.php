<?php
	include('functions.php');
	require_once('db.php');
    error_reporting(0);
    if(isset($_SESSION['user'])){
        $conn = getConnection();
    	// $sql = "select * from users where username='".$_SESSION['username']."'";
    	// $result = mysqli_query($conn, $sql);
    	// $row = mysqli_fetch_assoc($result);
?>
<link rel="stylesheet" href="style_a.css"/>
<?php include("header.php")?>

<?php include ("nav.php") ?><br><br>

<fieldset>
    <legend><b>EDIT PROFILE</b></legend>
	<form method="POST" action="updateProfile.php">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text" value="<?=$_SESSION['user']['username']?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text" value="<?=$_SESSION['user']['email']?>">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>				
			<tr><td colspan="4"><hr/></td></tr>
			
		</table>
		<hr/>
		<input type="submit" value="Submit" name="update">		
	</form>
</fieldset>
<?php include("footer.php")?>
<?php

}else{
    header("location: login.php");
}
?>