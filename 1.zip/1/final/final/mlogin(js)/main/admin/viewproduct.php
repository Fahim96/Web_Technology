<?php
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'multi_login';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = 'SELECT * 
		FROM product';
		
$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>
<link rel="stylesheet" href="style_a.css"/>
<?php include("header.php")?>

<?php include ("nav.php") ?><br><br>

<center>
	<table border="1" cellpadding="6" cellspacing="0">
		<tr><td colspan="5" align="CENTER">Products</td></tr>
		<tr>
			<td>ID</td><td>Product Name</td><td>Price</td><td>Quantity</td><td>Category</td>
		</tr>
		


		<?php
		while ($row = mysqli_fetch_array($query))
		{
			echo '<tr>
					<td>'.$row['id'].'</td>
					<td>'.$row['name'].'</td>
					<td>'.$row['price'].'</td>
					<td>'.$row['qyantity'].'</td>
					<td>'.$row['category'].'</td>
				</tr>';
		}?>
		</tbody>
		</td>
		</tr>
	</table>
</body>
</html>
<?php include("footer.php")?>