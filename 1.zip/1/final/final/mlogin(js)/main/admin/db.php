<?php

	$server = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "multi_login";

 function getConnection(){

 	$conn = mysqli_connect($GLOBALS['server'], $GLOBALS['dbuser'], $GLOBALS['dbpass'], $GLOBALS['dbname']);

 	return $conn;
 }

?>