<div class="footer">
  <h7>copyright@virtual warehouse</h7>
</div>