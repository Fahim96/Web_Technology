<?php
error_reporting(0);
if(count($_POST['degree'])>=2)
    echo "submitted";
else
    echo "please select at least two "

?>

<form action="#" method="POST">
	<fieldset>
        <legend>DEGREE</legend>
		<input style="width:30px" type="checkbox" name="degree[]" value="ssc">SSC
		<input style="width:30px" type="checkbox" name="degree[]" value="hsc">HSC
		<input style="width:30px" type="checkbox" name="degree[]" value="msc">BSc
		<input style="width:30px" type="checkbox" name="degree[]" value="bsc">MSc
		<hr/>
		<input type="submit" name="submit" value="Submit" >
	</fieldset>
</form>