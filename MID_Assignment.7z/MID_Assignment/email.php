

<?php
//  $nameErr="";
//if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["email"])) {
    echo "Email can not be empty";
  } 
  else if(! filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))
  {
	  echo "wrong";
  }
  else if(filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))
  {
	  echo "submitted";
  }	



?>
<form action="#" method="POST">
	<fieldset>
		<legend>Email</legend>
        <input type="text" name="email" value="" > <b> i </b> <br/><br/>
		<hr/>
		<input type="submit" name="submit" value="Submit" >
		
	</fieldset>
</form>
