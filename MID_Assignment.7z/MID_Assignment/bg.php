<?php
if(!isset($_POST["bg"]) || ($_POST["bg"] == "0")) 
	{
	echo "please select one";
	}
else
    echo "submitted";
?>
<form action="#" method="POST">
	<fieldset>
		<legend>BLOOD GROUP</legend>
		  <select name="bg">
				<option value="0"></option> 
				<option value="A">A-</option>
				<option value="A+">A+</option>
				<option value="B">B-</option>
				<option value="B+">B+</option>
				<option value="B+">AB+</option>
				<option value="B+">AB-</option>
				<option value="B+">O+</option>
		  </select>
		  <hr/>
		  
				<input type="submit" name="submit" value="Submit" >
			
	</fieldset>
</form>