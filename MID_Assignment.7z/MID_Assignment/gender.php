<?php 
if(!isset($_POST['gender'])){echo "Please select one";}
else
    echo "submitted";
?>
<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
		<input style="width:30px" type="radio" name="gender[]" value="male">Male
		<input style="width:30px" type="radio" name="gender[]" value="female">Female
		<input style="width:30px" type="radio" name="gender[]" value="other">Other
		<hr/>
		<input type="submit" name="submit" value="Submit" >
		
	</fieldset>
</form>