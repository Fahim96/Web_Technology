

<?php
$nameErr="";
//if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    echo "Name can not be empty";
  } 
  else if(! preg_match("/^[A-Z][a-z -]*(\s[A-Z][a-z -]*)+$/", $_POST["name"]))
  {
	  echo "wrong";
  }
  else if(preg_match("/^[A-Z][a-z -]*(\s[A-Z][a-z -]*)+$/" , $_POST["name"]))
  {
	  echo "submitted";
  }	



?>
<form action="#" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input type="text" name="name" value="" > * <br/><br/>
		<hr/>
		<input type="submit" name="submit" value="Submit" >
		
	</fieldset>
</form>
