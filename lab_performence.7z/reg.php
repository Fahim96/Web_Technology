<?php
error_reporting(0);
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		session_start();
		$_SESSION['variable_name_1'] =$_POST["username"];
	$_SESSION['variable_name_2'] =$_POST["email"];
	$_SESSION['variable_name_3'] =$_POST["Password"];
	$_SESSION['variable_name_4'] =$_POST["Confirm Password"];
	$_SESSION['variable_name_5'] =$_POST["GENDER"];
	$_SESSION['variable_name_6'] =$_POST["DATE OF BIRTH"];
	}
	
?>

 

<html>
<body>

	<form action="#" method="POST" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?> ">
	<fieldset>
	<legend>REGISTRATION</legend>
		<div align="center" >
			Name : <input type="username" name="username" /><br />
			<hr/>
			Email : <input type="email" name="email" /> <b> i </b> <br />
			<hr/>
			Username: <input type="Username" name="Username" /><br />
			<hr/>
			Password : <input type="password" name="pwd" /><br />
			<hr/>
			Confirm Password : <input type="password" name="pwd" /><br />
			<hr/>
			<fieldset>
		<legend>GENDER</legend>
		<input style="width:30px" type="radio" name="gender[]" value="male">Male
		<input style="width:30px" type="radio" name="gender[]" value="female">Female
		<input style="width:30px" type="radio" name="gender[]" value="other">Other
		
		
	</fieldset>
	<br/>
	<hr/>
	<fieldset>
		<legend>DATE OF BIRTH</legend>
		
		dd
		<input type="text" name="day" value="" style="width:40px">
		mm
		<input type="text" name="month" value="" style="width:40px">
		yy
		<input type="text" name="year" value="" style="width:40px">
		<b>(dd/mm/yy)</b> 
		<br/>
		<br/>
	</fieldset>
		<hr/>
		<input type="submit" value="Submit" />
		<input type="submit" value="Reset" />
		</div>
	</fieldset>
	</form>

</body>
</html>