<?php
/* 
1 = Check if the file uploaded is actually an image no matter what extension it has
2 = The uploaded files must have a specific image extension
*/

$validation_type = 1;

if($validation_type == 1)
{
	$mime = array('image/jpg' => 'jpg',
                  'image/jpeg' => 'jpeg',
                  'image/png' => 'png',
                 );
}
else if($validation_type == 2) // Second choice? Set the extensions
{
	$image_extensions_allowed = array('jpg', 'png', 'jpg');
}

$upload_image_to_folder = 'images/';
?>
<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form>
        <img width="128" src="../image/user.png" />
        <br />
        <input type="file">
        <hr />
        <input type="submit" value="Submit">
    </form>
</fieldset>